package hashcode2019;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HashcodeTest {

	@Test
	void test() {
		
	}
}
